<html>
</br>
<h1>[̲̅C̲̅][̲̅y̲̅][̲̅b̲̅][̲̅e̲̅][̲̅r̲̅] [̲̅T̲̅][̲̅K̲̅] [̲̅B̲̅][̲̅o̲̅][̲̅t̲̅] [̲̅C̲̅][̲̅o̲̅][̲̅n̲̅][̲̅t̲̅][̲̅r̲̅][̲̅o̲̅][̲̅l̲̅]</h1>
<h1>.̶.͖̗̱̲͔̹͕̬͔͙̞͈̘̮͉́.̛͕̬͉̻͖͞͠.̟̬̩͖̠.̟̖̦͓͙̖͠..͇̭̼̼͇ͅ.̨͙̪̣̝̬̯͔͍͓̰̺̩̟̖.̹̥̘.͍̰̦̳̮͎̬͝.̸̲̤̗͓͈̜̦͓̪͓̯̘͔̹̰̀.̲̩͖̞̖̠̻̙̟͞.͡͡͠.̵̢͔̺͓̠̰̜̘͈̬͠.̨̹̳̪̮̯̜́̀ͅ.̡͕ͅ.̴͚̠̗̳̪͉̕ͅ.҉̖͙̣.̧̛̞̤̳͉͕͈̠̣͎̭͘.̴͔̙̮̺̖͉̤̙͚̟͔̘..̥̹̥̙̣̮̺̜̲̻̺̲̤͟͞.͘҉̜̘̳̫͖̩̮̠͕̻͇̰..̥͇̹͉̯̥̝̖̣̬̼͚ͅ.̰̱͕̟̰̙̳̮̜̹̰ͅ..̛̘͟͞ͅ.̥̞̥̻̣̮̮̭̤͈ͅ.̡̬̻̯͙̖̭͔̰͉̘͎̰́ͅ.͝.̶̶͉̪̬͖̯̱͍͓̞̘̰..̻̼͚̝.̠̩̲͍̮͇͖͠.̷̵̢̘̗̗̯̲͎.̨.̰̗͜͞.͔̪̠͔̹̫̟̰̪̝̥́́͡.͘͜.̛.͏͉͎͎͍͓̖̼͚̭͉.̻̱͈.̵̯̼͙͚͉̠̰͚̲́.̛̫͓͍̰̤̱̥̫̳̗̺̗̪̖͡.͇͉̳̹̩̮.̲̙͓̼.͇͔͠.̬̝.̢̺̞͟ͅ.̖͔̺̗̥̻̙̕͡.͘͝.̵̷̢̻̥̣͎ͅ.̷̬̱̻̫̩͚̳̪.͟.̖̻̫̠̠͖̩͕̼.̞̠̝̹̗̥̜̤̫̤͎̫͘ͅ.̧̻̙̙̹͉̹̠̬͙̭.̭̦̬̟̲͍̙͍͕̱̲̹.͜͞.̲̳͢͠.̹̪.͕͖͈̩͓̹.̵͇̹̘̘̭̲̱̟̗̘͈͡.̛͈͉..̸͏҉̪̘̦̗̮͔̲͉..͕.͚͕͖̩̳̲̟͈̝̩̦̮ͅ.̠͖̘͈ͅ.</h1>
</br>
<table border=5 width=50% cellpadding=5 cellspacing=5>
    <tr>
	  <h1> <th colspan=4>(O)╚══╝║♫ ♪ ♫ ♪▄ █ ▄ █ ▄ ▄ █ ▄ █ ▄ █ in- - - - - - - - - - - -●Max </th></h1>
    </tr>
</table>
</br>
<h1>.̌ͨ̔̄.̛̎͌͂ͬ͊ͣ͗̑̈ͮͬͤ.̏̿̉̒ͭ̾̔́͛̀̇̓̃.͢.ͪ̉̓ͯ͌͐̎̈̌̐̾̒͒ͩ̚͜.͘.̇̀ͬ.ͬ̑ͩ̅̑́͆̑̕.ͤ̄̽̓̔͗ͦ̂͋̒ͬ.ͧ̊̇ͮ̊͛͑̂͗.̷̡͝.̾̓̎̽ͣͨ̿͌͆̚.̀́.̊͂̍͆͂.̴̍̇.͐̚.̸̾͊̈̄ͤ̓̄ͬ̅ͫͭ̚.͐͟.̍̎͆̏̚.̴̡̢́͋ͨ̿.̏ͣ̉͠..͗ͦ͂̐͐́͋ͬͯ҉҉͠.҉̡͜.ͬ͌̃̓̑͐̃̚.̸.̷̀͐̆̀͡...͐̓ͮͨ̉̀́.̡̨ͩͫ͊ͫͪ̄ͪͯ̈͟.̶ͮ̓̇̎ͦͩ̊ͦ͐ͥ̂̉͢͡.͒̃̐̚͜.̡.ͫ͊ͣ̿̿͆͆̇͊̿́͞͞.ͩ͑̑͒̓̐̎̉̅̓ͧ̏..̴̡̌̋ͯ͆ͪ̓̏̌ͥ͟..͛̈ͤͫͣ͊̋̈́̽̾ͮ̈́͌.ͤ̌ͪͨ̋̀́.̆͘.͡.̆ͭ̀͐͌͋̊ͣ̅͒ͩͦͬ̏.̌͑ͪ̐ͩͭ҉͝.̑̀̅̐̓̃̕.͘͢.̎̔͌ͫ̀͛ͪ̾.̛͋̿̑͊͛̒̂̌ͥ̃̈́̂͋ͤ.̷͛͐͑.̆̅̓̐̑̍̊ͨ̎ͦ̈́͆..ͮ̋́̋̀͊̊.̷̡̛̆̏̽̎̇̌̎ͮ͋ͬ̑̐̆.̌.ͬͨͩͩ̅̄̚..ͥͩ̔̐̓ͣ́͘͢.̡̢̀ͩ̂ͯ͊́͂̅́ͥͮ̃͑ͥ.ͤ̔͒ͦͮ҉.̵̸́͋ͮ̋̋̔͝.̡̢̑̅ͭͭ̑̈ͯ̉ͤ́ͣ̅ͮ̏ͪ͟.̸̈ͤ͜͡.̅̇́̌.̷͑͋̔̽ͬ̃́͋̉̀̅.̉̎̌ͥ̆ͭ͒ͪ͞.̎ͤ̄̃̌ͭ̅̀̕͡.͋͐ͧ̒̄ͪ͗̉̈̇̂̒̅̆͋.ͬͫ͑͂̈́́̂͊̒.̋͛ͪ͒̒̉̎̾̚.̛ͩͪ̉̉̆̏̎̽.͌̈́̓ͮ̓̀̚</h1>

<div align="center"><a href="https://instagram.com/_aquariusman"><img src="https://images.cooltext.com/5135666.gif" width="576" height="104" alt="Cyber TK" /></div>
<br><b>✦    Continue To Follow Cyber-TK </b>
<br><b>✦    Node -V 8.4.0 </b>
<br><b>✦    Nodejs Version update  </b>
<br><b>✦   npm i -g npm </b>
</hr>
<br><b>✦   OTOMATİK OLARAK ÇALIŞTIRMAK İÇİN AŞAĞIDAKİ ADIMI İZLEYİNİZ </b></br>
<br><b>✦   git clone https://gitlab.com/CyberTKR/CyberTK-Kicker</b></br></b></br>
<br><b>✦   cd CyberTK-Kicker </b></br>
<br><b>✦   chmod +x cybertkautoprogram </b></br>
<br><b>✦   ./cybertkautoprogram </b></br>
<br><b>================= [AUTO ÇALIŞTIRMA KOMUTLARI YUKARIDAKİLER] =================</b></br>
<br><b>================= [MANUEL ÇALIŞTIRMA KOMUTLARI AŞAĞIDAKİLER] =================</b></br>
<br><b>✦   Bot İs Running </b></br>
<br><b>✦   sudo apt-get update -sudo apt-get install build-essential checkinstall libssl-dev</b></br>
<br><b>✦   curl -o- https://raw.githubusercontent.com/creationix/nvm/v0.32.1/install.sh | bash </b></br>
<br><b>✦   nvm install v8.9.1</b></br>
<br><b>✦   nvm use v8.9.1</b></br>
<br><b>✦   nvm ls</b></br>
<br><b>✦   nvm alias default node</b></br>

<br><b>✦   Bot İs Running </b></br>
<br><b>✦   sudo apt-get install nodejs</b></br>
<br><b>✦   https://gitlab.com/CyberTKR/CyberTK-Kicker</b></br>
<br><b>✦   ls</b></br>
<br><b>✦   cd CyberTK-Kicker</b></br>
<br><b>✦   npm i</b></br>
<br><b>✦   npm i -g npm</b></br>
<br><b>✦   npm start</b></br>
<h2><b> Official Account's </b></h2>
<br><b>✦  Line Contact ✔⇩ </b></br>
<br><b>✦  cybertk0  </b></br>
<br><b>✦ ⇩Add⇩Line⇩ </b></br>
<p><a href="https://line.me/R/ti/p/~cybertk0" rel="nofollow"><img height="36" border="0" alt="Add Friend" src="https://camo.githubusercontent.com/035d0206e65dfbdfb7cdabbd6f5a1f4fb59f0e41/68747470733a2f2f7363646e2e6c696e652d617070732e636f6d2f6e2f6c696e655f6164645f667269656e64732f62746e2f656e2e706e67" data-canonical-src="https://scdn.line-apps.com/n/line_add_friends/btn/en.png" style="max-width:100%;"></a></p>
</br><b>✦    CyberTKBOT </b>
</br><b>✦    Cybertk Bot scripti'dir. </b>
</br><b>✦   Grup savunmasi amacli kullanilmalidir. </b>
</br><b>✦ Baska herhangi bir amacla kullanilmak icin duzenlenmesinden ve, </b>
</br><b>✦   kullanilmasindan cybertk sorumlu degildir. </b>
<br/><b>✦ İnstagram Account ➥<a href="http://instagram.com/_aquariusman " title="Tolga instagram Account"> _aquariusman </a> </b>
<br/><b>✦Youtube Channel ➥<a href="https://youtube.com/channel/UC9AyYKWovERexyOFy3h4rdw" title="CyberTK Youtube Channel"> CyberTK Official Channel </a></b>
</br>
</br>
<br/><b>✦<a href="mailto:tolgajames2@gmail.com">To send a mail, just click,<b> </a>
</br><p><b>✦<a href="mailto:tolgajames2@gmail.com">On the Mail Icon below.↴⇩<b> </a></p>
</br><a href="mailto:tolgajames2@gmail.com"> <img src="https://github.com/CyberTKR/CyberJS/blob/master/CyberJS/curve-thrift/mail.png" width=100/></a>
</body>
 </html>
